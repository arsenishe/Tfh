package com.example.bedrocklauncher

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 12, 11)
    private val panel = Color.rgb(25, 29, 27)
    private val green = Color.rgb(65, 205, 105)
    private val white = Color.rgb(242, 245, 243)
    private val muted = Color.rgb(160, 170, 164)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv() and
                View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(24))
        }
        scroll.addView(root)

        val brand = text("BEDROCK", 30f, green, true)
        root.addView(brand)
        root.addView(text("LAUNCHER  •  BLACK EDITION", 12f, muted, true).also {
            it.letterSpacing = 0.12f
        })
        space(root, 26)

        val status = card(root)
        status.addView(text("ВАША ИГРА", 12f, muted, true))
        status.addView(text("Minecraft Bedrock", 21f, white, true))
        status.addView(text("Ожидаемая версия: 26.32", 13f, muted, false))
        space(root, 16)

        val play = button("▶   PLAY MINECRAFT", green, Color.BLACK)
        root.addView(play, matchWrap())
        play.setOnClickListener { launchMinecraft() }
        space(root, 22)

        root.addView(text("БЫСТРЫЕ ИНСТРУМЕНТЫ", 13f, muted, true))
        space(root, 10)

        val boost = button("⚡   BOOST MODE", panel, white)
        root.addView(boost, matchWrap())
        boost.setOnClickListener {
            Toast.makeText(this,
                "Режим лаунчера включён. Он не меняет настройки игрового движка и не гарантирует рост FPS.",
                Toast.LENGTH_LONG).show()
        }
        space(root, 10)

        val addons = button("📦   ADDONS & TEXTURES", panel, white)
        root.addView(addons, matchWrap())
        addons.setOnClickListener {
            Toast.makeText(this, "Управление аддонами добавим в следующей версии.", Toast.LENGTH_SHORT).show()
        }
        space(root, 10)

        val settings = button("⚙   SETTINGS", panel, white)
        root.addView(settings, matchWrap())
        settings.setOnClickListener {
            Toast.makeText(this, "Настройки устройства и лаунчера появятся в следующей версии.", Toast.LENGTH_SHORT).show()
        }
        space(root, 22)

        val note = card(root)
        note.addView(text("ОБ ОПТИМИЗАЦИИ", 12f, green, true))
        note.addView(text(
            "Лаунчер запускает официально установленный Minecraft. Android не позволяет стороннему приложению напрямую разгонять игровой движок или гарантированно повышать FPS. BOOST MODE пока служит демонстрационным переключателем.",
            13f, muted, false
        ))
        space(root, 18)
        root.addView(text("BEDROCK LAUNCHER  •  v1.0", 11f, muted, false).apply {
            gravity = Gravity.CENTER
        })

        setContentView(scroll)
    }

    private fun launchMinecraft() {
        val intent = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this,
                "Minecraft не найден. Установи официальную версию из поддерживаемого магазина.",
                Toast.LENGTH_LONG).show()
        }
    }

    private fun card(parent: LinearLayout): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(15), dp(16), dp(15))
            setBackgroundColor(panel)
            parent.addView(this, matchWrap())
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }

    private fun button(label: String, color: Int, textColor: Int): Button =
        Button(this).apply {
            text = label
            textSize = 14f
            setTextColor(textColor)
            setBackgroundColor(color)
            isAllCaps = false
            minHeight = dp(54)
        }

    private fun space(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
